<?php
    include_once "../config/dbconnect.php";

    $v_id=$_POST['v_id'];
    $product= $_POST['product'];
    $size= $_POST['size'];
    $qty= $_POST['qty'];
   
    $updateItem = mysqli_query($conn,"UPDATE service_avalability SET 
        option_id=$product, 
        gt_id=$size,
        available_num=$qty 
        WHERE savail_id=$v_id");


    if($updateItem)
    {
        echo "true";
    }
?>