<?php
    include_once "../config/dbconnect.php";
    
    if(isset($_POST['upload']))
    {
       
        $catname = $_POST['c_name'];
       
         $insert = mysqli_query($conn,"INSERT INTO technician
         (f_name) 
         VALUES ('$catname')");
 
         if(!$insert)
         {
             echo mysqli_error($conn);
             header("Location: ../dashboard.php?technician=error");
         }
         else
         {
             echo "Records added successfully.";
             header("Location: ../dashboard.php?technician=success");
         }
     
    }
        
?>