<?php

    include_once "../config/dbconnect.php";
    
    $id=$_POST['record'];
    $query="DELETE FROM service_avalability where savail_id='$id'";

    $data=mysqli_query($conn,$query);

    if($data){
        echo"Deleted";
    }
    else{
        echo"Not able to delete";
    }
    
?>