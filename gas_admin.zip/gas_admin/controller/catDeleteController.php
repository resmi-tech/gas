<?php

    include_once "../config/dbconnect.php";
    
    $c_id=$_POST['record'];
    $query="DELETE FROM services where service_id='$c_id'";

    $data=mysqli_query($conn,$query);

    if($data){
        echo"Service Item Deleted";
    }
    else{
        echo"Not able to delete";
    }
    
?>