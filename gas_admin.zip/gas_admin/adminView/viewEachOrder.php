<div class="container">
<table class="table table-striped">
    <thead>
        <tr>
            <th>S.N.</th>
            
            <th>Name</th>
            <th>lb</th>
           
            <th>Unit Price</th>
        </tr>
    </thead>
    <?php
        include_once "../config/dbconnect.php";
        $ID= $_GET['orderID'];
        //echo $ID;
        $sql="SELECT * from service_avalability v, order_details d 
        where v.savail_id=d.savail_id AND
        d.order_id=$ID";
        $result=$conn-> query($sql);
        $count=1;
        if ($result-> num_rows > 0){
            while ($row=$result-> fetch_assoc()) {
                $v_id=$row['savail_id'];
    ?>
                <tr>
                    <td><?=$count?></td>
                    <?php
                       $subqry="SELECT * from options p, service_avalability v
                       where p.option_id=v.option_id AND v.savail_id=$v_id";
                       $res=$conn-> query($subqry);
                       if($row2 = $res-> fetch_assoc()){
                    ?>
                    
                    <td><?=$row2["option_name"] ?></td>

                    <?php
                        }

                        $subqry2="SELECT * from gas_tech s, service_avalability v
                        where s.gt_id=v.gt_id AND v.savail_id=$v_id";
                        $res2=$conn-> query($subqry2);
                        if($row3 = $res2-> fetch_assoc()){
                        ?>
                    <td><?=$row3["weight_techid"] ?></td>
                    <?php
                        }
                    ?>
                   
                    <td><?=$row["price"]?></td>
                </tr>
    <?php
                $count=$count+1;
            }
        }else{
            echo "error";
        }
    ?>
</table>
</div>
