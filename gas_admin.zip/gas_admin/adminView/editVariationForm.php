<div class="container p-5">

<h4>Edit Details</h4>
<?php
    include_once "../config/dbconnect.php";
	$ID=$_POST['record'];
	$qry=mysqli_query($conn, "SELECT * from service_availability Where savail_id='$ID'");
	$numberOfRow=mysqli_num_rows($qry);
	if($numberOfRow>0){
		while($row1=mysqli_fetch_array($qry)){
      $pID=$row1["option_id"];
      $sID=$row1["gt_id"]
?>
<form id="update-Items" onsubmit="updateVariations()" enctype='multipart/form-data'>
	<div class="form-group">
      <input type="text" class="form-control" id="v_id" value="<?=$row1['savail_id']?>" hidden>
    </div>
    <div class="form-group">
        <label>Options:</label>
        <select id="product" >
        <?php

        $sql="SELECT * from options where option_id=$pID";
        $result = $conn-> query($sql);

        if ($result-> num_rows > 0){
        while($row = $result-> fetch_assoc()){
            echo"<option selected value='".$row['option_id']."'>".$row['option_name'] ."</option>";
        }
        }
        ?>
        <?php

            $sql="SELECT * from options where option_id!=$pID";
            $result = $conn-> query($sql);

            if ($result-> num_rows > 0){
            while($row = $result-> fetch_assoc()){
                echo"<option value='".$row['option_id']."'>".$row['option_name'] ."</option>";
            }
            }
        ?>
        </select>
    </div>
    <div class="form-group">
        <label>Gas/Technician:</label>
        <select id="size" >
        <?php

            $sql="SELECT * from gas_tech where gt_id=$sID";
            $result = $conn-> query($sql);

            if ($result-> num_rows > 0){
            while($row = $result-> fetch_assoc()){
                echo"<option selected value='".$row['gt_id']."'>".$row['weight_techid'] ."</option>";
            }
            }
        ?>
        <?php

            $sql="SELECT * from gas_tech where gt_id!=$sID";
            $result = $conn-> query($sql);

            if ($result-> num_rows > 0){
            while($row = $result-> fetch_assoc()){
                echo"<option value='".$row['gt_id']."'>".$row['weight_techid'] ."</option>";
            }
            }
        ?>
        </select>
    </div>
    <div class="form-group">
        <label for="qty">Service availability:</label>
        <input type="number" class="form-control" id="qty" value="<?=$row1['available_num']?>"  required>
    </div>
    <div class="form-group">
      <button type="submit" style="height:40px" class="btn btn-primary">Update </button>
    </div>
    <?php
    		}
    	}
    ?>
  </form>

  
</div>